# 🦁 LEO - VERCEL FUNCIONAL (ERROR 404 ARREGLADO)

## ✅ ESTA VERSIÓN SÍ FUNCIONA EN VERCEL

---

## 📦 ESTRUCTURA CORRECTA:

```
LEO-VERCEL-FUNCIONAL/
├── index.html       ← Página principal
├── login.html       ← Login
├── vercel.json      ← Config correcta
└── api/
    └── chat.js      ← API de Groq
```

---

## 🚀 SUBIR A VERCEL (5 MINUTOS):

### **PASO 1 - Subir a GitHub:**

1. Ve a: **github.com**
2. New repository → Nombre: **leo-vercel**
3. **IMPORTANTE:** Sube TODOS los archivos manteniendo la estructura:
   - index.html (en la raíz)
   - login.html (en la raíz)
   - vercel.json (en la raíz)
   - Carpeta **api/** con **chat.js** dentro

4. Commit

### **PASO 2 - Deploy en Vercel:**

1. Ve a: **vercel.com**
2. Sign up con GitHub
3. Add New → Project
4. Import tu repo **leo-vercel**
5. **NO CAMBIES NADA** - deja todo por defecto
6. Deploy

### **PASO 3 - API Key:**

1. Ve a: **console.groq.com**
2. API Keys → Create
3. Copia la key

4. En Vercel:
   - Settings → Environment Variables
   - Add:
     ```
     GROQ_API_KEY = tu_key_aqui
     ```
   - Save

### **PASO 4 - Redeploy:**

1. Deployments
2. ... (tres puntos) → Redeploy
3. Espera 1 minuto

### **PASO 5 - ¡Funciona!**

Visit → Tu Leo funcional

---

## ⚠️ MUY IMPORTANTE:

**La estructura DEBE ser así en GitHub:**

```
✅ CORRECTO:
leo-vercel/
├── index.html     ← Directamente aquí
├── login.html
├── vercel.json
└── api/
    └── chat.js

❌ INCORRECTO:
leo-vercel/
└── carpeta/
    ├── index.html  ← NO dentro de otra carpeta
    └── ...
```

---

## 🔧 SI SIGUE DANDO 404:

**Verifica en GitHub:**
1. ¿index.html está en la RAÍZ del repo?
2. ¿La carpeta api/ está en la raíz?
3. ¿vercel.json está en la raíz?

**Si NO:**
1. Borra todo en GitHub
2. Vuelve a subir manteniendo la estructura correcta

---

## ✅ CHECKLIST:

- [ ] Descargué los 4 archivos
- [ ] Subí a GitHub en la estructura correcta
- [ ] index.html en la raíz (NO en subcarpeta)
- [ ] api/chat.js en carpeta api/
- [ ] Connected Vercel con GitHub
- [ ] Deploy
- [ ] Agregué GROQ_API_KEY
- [ ] Redeploy
- [ ] ¡Funciona sin 404!

---

**ESTA VERSIÓN SÍ FUNCIONA** ✅

**Jhosua Sebastian Vasquez Bushberek - 2026**
